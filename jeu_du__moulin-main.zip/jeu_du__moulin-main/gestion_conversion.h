#ifndef GESTION_CONVERSION_H_INCLUDED
#define GESTION_CONVERSION_H_INCLUDED

#include "gestion_pions.h"

Point traduire(char , char );
void InverseTraduire(int, int);

#endif // GESTION_CONVERSION_H_INCLUDED
