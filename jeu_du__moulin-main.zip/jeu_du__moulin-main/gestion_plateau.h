#ifndef GESTION_PLATEAU_H_INCLUDED
#define GESTION_PLATEAU_H_INCLUDED

void AfficherPlateau();
void InitialiserPlateau();


#endif // GESTION_PLATEAU_H_INCLUDED
