#ifndef GESTION_IA_DEPLACEMENT_H_INCLUDED
#define GESTION_IA_DEPLACEMENT_H_INCLUDED

void un_deplacement_normal_IA(Joueur machine, Joueur j2);

#endif // GESTION_IA_DEPLACEMENT_H_INCLUDED
