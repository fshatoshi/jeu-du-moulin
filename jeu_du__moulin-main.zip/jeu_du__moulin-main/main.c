#include <stdio.h>
#include <stdlib.h>

#include "gestion_plateau.h"
#include "gestion_jeu.h"

int main()
{
    menu();

    return 0;
}
