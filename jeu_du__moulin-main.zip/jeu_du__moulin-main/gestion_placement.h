#ifndef GESTION_PLACEMENT_H_INCLUDED
#define GESTION_PLACEMENT_H_INCLUDED

#include "gestion_joueurs.h"

void PlacerPion(Joueur);
void TourPlacement(Joueur, Joueur);
void PhaseDePlacement(Joueur, Joueur);

#endif // GESTION_PLACEMENT_H_INCLUDED
