#ifndef GESTION_MOULIN_H_INCLUDED
#define GESTION_MOULIN_H_INCLUDED

#include "gestion_joueurs.h"


int PionAlignesHorizontal(Joueur );
int PionAlignesVertical(Joueur );

#endif // GESTION_MOULIN_H_INCLUDED
